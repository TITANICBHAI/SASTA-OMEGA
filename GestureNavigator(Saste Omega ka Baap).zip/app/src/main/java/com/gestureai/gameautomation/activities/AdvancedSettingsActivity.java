package com.gestureai.gameautomation.activities;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.gestureai.gameautomation.R;

public class AdvancedSettingsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);  // Use existing layout
    }
}